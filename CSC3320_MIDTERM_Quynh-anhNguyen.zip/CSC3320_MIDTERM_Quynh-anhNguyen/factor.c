#include <stdio.h>
int factorial(int num) {
int factor;
if(num!=1) {
factor = num*factorial(num-1);
}
else {
factor = 1;
}
return factor;
}
int main() {
int num = 4;
printf("%d\n",factorial(num));
return 0;
}