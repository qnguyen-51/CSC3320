#!/bin/bash
echo "Enter a number of days"
read input
find /home/qnguyen51 -atime +$input -type f | zip compress -@
