#include <stdio.h>
int main() {
int num1 = 15;
printf("Starting num: %d\n",num1);
int num2 = ((num1)<<3) + (~num1);
printf("Result: %d\n",num2);
}