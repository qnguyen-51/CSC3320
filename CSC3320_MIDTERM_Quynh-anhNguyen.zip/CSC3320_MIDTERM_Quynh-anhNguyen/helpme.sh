#!/bin/bash
echo "Type in a command"
read cmd_input
if grep -q $cmd_input mandatabase.txt
then grep $cmd_input mandatabase.txt
else
echo "sorry, I cannot help you"
fi
